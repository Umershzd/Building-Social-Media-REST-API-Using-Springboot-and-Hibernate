package com.rest_api.Restful_Api_for_SocialMedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulApiForSocialMediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
