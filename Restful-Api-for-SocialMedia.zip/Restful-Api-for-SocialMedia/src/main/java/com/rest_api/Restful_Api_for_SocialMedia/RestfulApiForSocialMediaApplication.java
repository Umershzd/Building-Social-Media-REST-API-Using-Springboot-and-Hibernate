package com.rest_api.Restful_Api_for_SocialMedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulApiForSocialMediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulApiForSocialMediaApplication.class, args);
	}

}
